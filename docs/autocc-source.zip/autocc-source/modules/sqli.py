"""Stage 2 — sqli scan. wraps sqlmap against target list (batched)."""
import subprocess
import time
from pathlib import Path
from modules.utils import which
from modules.notifier import Notifier

BATCH = 50  # targets per sqlmap run — progress + /kill granularity


class SQLiScanner:
    def __init__(self, cfg, logger):
        self.cfg = cfg
        self.log = logger
        self.raw = Path(cfg["paths"]["raw"])
        self.rc = cfg["sqli"]

    @staticmethod
    def collect_injectables(out_dir: Path) -> set:
        """scan sqlmap output dir for injectable urls (works on partial runs)."""
        injectables = set()
        if not out_dir.exists():
            return injectables
        for f in out_dir.rglob("*"):
            if not f.is_file():
                continue
            try:
                txt = f.read_text(errors="ignore")
            except Exception:
                continue
            for line in txt.splitlines():
                if "Parameter:" in line and "http" in line:
                    for token in line.split():
                        if token.startswith("http"):
                            injectables.add(token)
        return injectables

    def _base_cmd(self, out_dir: Path):
        cmd = [
            self.rc["sqlmap_bin"],
            "--batch",
            f"--level={self.rc['level']}",
            f"--risk={self.rc['risk']}",
            f"--threads={self.rc['threads']}",
            f"--technique={self.rc['technique']}",
            f"--tamper={self.rc['tamper']}",
            f"--output-dir={out_dir}",
            "--flush-session",
        ]
        if self.rc.get("random_agent"):
            cmd.append("--random-agent")
        if self.rc.get("delay"):
            cmd.append(f"--delay={self.rc['delay']}")
        return cmd

    def run(self):
        targets_file = self.raw / "targets.txt"
        if not targets_file.exists():
            self.log.error("[sqli] no targets.txt — run recon first")
            return

        if not which(self.rc["sqlmap_bin"]):
            self.log.error(f"[sqli] {self.rc['sqlmap_bin']} not found in PATH")
            return

        targets = [t.strip() for t in targets_file.read_text().splitlines()
                   if t.strip()]
        if not targets:
            self.log.error("[sqli] targets.txt is empty")
            return

        out_dir = self.raw / "sqlmap_out"
        out_dir.mkdir(exist_ok=True)
        kill_file = self.raw / ".kill"
        batch_file = self.raw / ".sqli_batch.txt"
        sqlmap_log = self.raw / "sqlmap_progress.log"

        total = len(targets)
        self.log.info(f"[sqli] scanning {total} targets, {BATCH}/batch")

        for start in range(0, total, BATCH):
            if kill_file.exists():
                kill_file.unlink(missing_ok=True)
                self.log.warning(
                    f"[sqli] /kill at {start}/{total} — partial results")
                break
            chunk = targets[start:start + BATCH]
            batch_file.write_text("\n".join(chunk))
            cmd = self._base_cmd(out_dir) + ["-m", str(batch_file)]
            self.log.info(
                f"[sqli] batch {start + 1}-{start + len(chunk)}/{total}")
            try:
                with open(sqlmap_log, "w") as lf:
                    proc = subprocess.Popen(
                        cmd, stdout=lf, stderr=subprocess.STDOUT, text=True)
                    while proc.poll() is None:
                        if kill_file.exists():
                            self.log.warning("[sqli] /kill — stopping sqlmap")
                            proc.terminate()
                            try:
                                proc.wait(timeout=15)
                            except subprocess.TimeoutExpired:
                                proc.kill()
                            break
                        time.sleep(1)
            except Exception as e:
                self.log.error(f"[sqli] batch failed: {e}")
            done = min(start + BATCH, total)
            n_inj = len(self.collect_injectables(out_dir))
            self.log.info(
                f"[sqli] progress {done}/{total} injectables={n_inj}")

        batch_file.unlink(missing_ok=True)
        found = self.collect_injectables(out_dir)
        (self.raw / "injectable.txt").write_text("\n".join(sorted(found)))
        self.log.info(f"[sqli] done — {len(found)} injectables -> injectable.txt")

        Notifier(self.cfg, self.log).send(
            f"*[sqli done]*\ninjectables: {len(found)}",
            stage="sqli"
        )
