"""Stage 7 — emit final records in configured formats."""
import csv
import json
from pathlib import Path
from modules.notifier import Notifier


class OutputWriter:
    def __init__(self, cfg, logger):
        self.cfg = cfg
        self.log = logger
        self.raw = Path(cfg["paths"]["raw"])
        self.final = Path(cfg["paths"]["final"])
        self.oc = cfg["output"]

    def run(self):
        in_file = self.raw / "final.csv"
        if not in_file.exists():
            self.log.error("[output] no final.csv")
            return

        rows = list(csv.DictReader(in_file.open()))
        base = self.final / self.oc["base_name"]

        if "txt" in self.oc["formats"]:
            with (base.with_suffix(".txt")).open("w") as f:
                for r in rows:
                    f.write(f"{r['card']}\n")

        if "csv" in self.oc["formats"]:
            with (base.with_suffix(".csv")).open("w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=["card", "brand", "raw_line", "source"])
                w.writeheader()
                w.writerows(rows)

        if "json" in self.oc["formats"]:
            with (base.with_suffix(".json")).open("w") as f:
                json.dump(rows, f, indent=2)

        self.log.info(f"[output] {len(rows)} records exported -> {base}.*")

        n = Notifier(self.cfg, self.log)
        n.send(f"*[output done]*\nrecords: {len(rows)}", stage="output")
        n.send_file(str(base.with_suffix(".txt")), caption="final dump")
