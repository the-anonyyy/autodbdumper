"""dork generator — all variants: generic, HQ, CMS, country, file, SQLi."""
import random
from pathlib import Path


FILE_TYPES = ["sql", "env", "bak", "log", "txt", "csv", "xml", "json", "zip", "gz"]
CMS_LIST = ["wordpress", "joomla", "drupal", "magento", "prestashop",
            "opencart", "woocommerce", "shopify", "laravel", "django"]
COUNTRIES = ["in", "us", "uk", "ru", "br", "id", "tr", "pk", "bd", "ng"]

GENERIC_TEMPLATES = [
    'inurl:"{kw}"',
    'intitle:"{kw}"',
    'intext:"{kw}"',
    'site:{tld} inurl:"{kw}"',
    'inurl:"{kw}" ext:php',
    'inurl:"{kw}" ext:asp',
    'inurl:"{kw}" ext:aspx',
    'inurl:"{kw}" ext:jsp',
]

SQLI_TEMPLATES = [
    'inurl:"{kw}.php?id="',
    'inurl:"{kw}.asp?id="',
    'inurl:"{kw}.aspx?id="',
    'inurl:"{kw}.jsp?id="',
    'inurl:"{kw}.php?cat="',
    'inurl:"{kw}.php?product="',
    'inurl:"{kw}.php?page="',
    'inurl:"{kw}.php?item="',
]

FILE_TEMPLATES = [
    'site:{tld} ext:{ft}',
    'site:{tld} inurl:"{kw}" ext:{ft}',
    'site:{tld} intitle:index.of ext:{ft}',
]

CMS_TEMPLATES = [
    'inurl:"{kw}" "wp-content"',
    'inurl:"{kw}" "wp-includes"',
    'inurl:"{kw}" "components/com_"',
    'inurl:"{kw}" "sites/default/files"',
    'inurl:"{kw}" "skin/frontend"',
    'inurl:"{kw}" "modules/"',
]

COUNTRY_TEMPLATES = [
    'inurl:"{kw}" site:{tld}',
    'inurl:"{kw}.php?id=" site:{tld}',
    'site:{tld} inurl:"{kw}"',
]


class DorkGen:
    def __init__(self, cfg, logger):
        self.cfg = cfg
        self.log = logger
        self.raw = Path(cfg["paths"]["raw"])

    def _write(self, name, items):
        p = self.raw / name
        p.write_text("\n".join(sorted(set(items))))
        self.log.info(f"[dorks] {len(items)} -> {name}")

    def generic(self, keywords: list):
        out = []
        for kw in keywords:
            for t in GENERIC_TEMPLATES:
                out.append(t.format(kw=kw, tld=random.choice(
                    ["com", "net", "org", "io"])))
        self._write("dorks_generic.txt", out)

    def hq_sqli(self, keywords: list):
        out = []
        for kw in keywords:
            for t in SQLI_TEMPLATES:
                out.append(t.format(kw=kw))
        self._write("dorks_sqli.txt", out)

    def files(self):
        out = []
        for tld in ["com", "net", "org", "io", "in"]:
            for ft in FILE_TYPES:
                for t in FILE_TEMPLATES:
                    out.append(t.format(tld=tld, ft=ft, kw=ft))
        self._write("dorks_files.txt", out)

    def cms(self, keywords: list):
        out = []
        for kw in keywords:
            for t in CMS_TEMPLATES:
                out.append(t.format(kw=kw))
        self._write("dorks_cms.txt", out)

    def country(self, keywords: list):
        out = []
        for kw in keywords:
            for cc in COUNTRIES:
                for t in COUNTRY_TEMPLATES:
                    out.append(t.format(kw=kw, tld=cc))
        self._write("dorks_country.txt", out)

    def all(self, keywords: list):
        self.generic(keywords)
        self.hq_sqli(keywords)
        self.files()
        self.cms(keywords)
        self.country(keywords)
